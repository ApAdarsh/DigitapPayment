package com.curebay.paymentservices.dto;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Data
public class PayURequestDTO {

    @NotBlank(message = "Service type is required")
    private String serviceType;

    @NotNull(message = "Amount is required")
    private Double amount;

    @NotBlank(message = "Product information is required")
    private String productInfo;

    @NotBlank(message = "First name is required")
    private String firstname;

//    @Email(message = "Invalid email format")
//    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Phone number is required")
    private String phone;

    @NotEmpty(message = "Patient ID is required")
    private String patientId;

}
