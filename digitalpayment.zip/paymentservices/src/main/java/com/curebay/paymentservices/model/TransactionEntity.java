package com.curebay.paymentservices.model;

import com.curebay.paymentservices.constants.TransactionStatus;
import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "PAYUTRANSACTIONS", uniqueConstraints = {@UniqueConstraint(columnNames = "txnid")})
@Data
public class TransactionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "AMOUNT", nullable = false)
    private BigDecimal amount;

    @Column(name = "CREATEDBY", nullable = false)
    private String createdBy;

    @Column(name = "CREATEDDATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "EMAIL", nullable = false)
    private String email;

    @Column(name = "FIRSTNAME", nullable = false)
    private String firstName;

    @Column(name = "HASH", nullable = false)
    private String hash;

    @Column(name = "MODIFIEDBY", nullable = false)
    private String modifiedBy;

    @Column(name = "MODIFIEDDATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;

    @Column(name = "PATIENTID", nullable = false)
    private String patientId;

    @Column(name = "PAYMENTMODE")
    private String paymentMode;

    @Column(name = "PAYUCHECK")
    private Integer payuCheck;

    @Column(name = "PAYUMONEYID")
    private String payuMoneyId;

    @Column(name = "PAYUREQUEST", columnDefinition = "MEDIUMTEXT")
    private String payuRequest;

    @Column(name = "PHONE", nullable = false)
    private String phone;

    @Column(name = "PRODUCTINFO", nullable = false)
    private String productInfo;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "STATUS")
    private Integer status; // This can be changed to TransactionStatus if you implement the enum

    @Column(name = "STATUSREMARKS")
    private String statusRemarks;

    @Column(name = "TXNDATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date txnDate;

    @Column(name = "TXNID", nullable = false)
    private String txnId;

    // Lifecycle callbacks to set created and modified dates
    @PrePersist
    protected void onCreate() {
        createdDate = new Date();
        modifiedDate = new Date();
        status = TransactionStatus.IN_PROGRESS.getCode(); // Set initial status to PENDING
    }

    @PreUpdate
    protected void onUpdate() {
        modifiedDate = new Date();
    }
}