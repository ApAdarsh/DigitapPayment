package com.curebay.paymentservices.constants;

public class ErrorConstants {

    public static final String OK = "200";
    public static final String NOT_FOUND = "404";
    public static final String BAD_REQUEST = "400";
    public static final String SUCCESS = "SUCCESS";
    public static final String NO_DATA_FOUND = "No data found";
    public static final String NO_CONTENT = "Empty data found";
    public static final String FAILED = "FAILED";
}
