package com.curebay.paymentservices.services.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.curebay.paymentservices.config.HashGenerator;
import com.curebay.paymentservices.model.TransactionEntity;
import com.curebay.paymentservices.repo.TransactionRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.curebay.paymentservices.config.PayUCategoryConfig;
import com.curebay.paymentservices.constants.ErrorConstants;
import com.curebay.paymentservices.services.PayUService;

import java.math.BigDecimal;
import java.util.Date;

@Service
@Slf4j
public class PayUServiceImpl implements PayUService {

    @Value("${surl}")
    private String surl;

    @Value("${furl}")
    private String furl;

    @Autowired
    private PayUCategoryConfig payUCategoryConfig;

    @Autowired
    private TransactionRepo transactionRepo;

    @Override
    public String initiatePayment(String serviceType, double amount, String productInfo, String firstname, String email, String phone, String patientId){
        try {
            // Validate input parameters
            if (serviceType == null || productInfo == null || firstname == null || email == null || phone == null || patientId == null ||
                    serviceType.isEmpty() || productInfo.isEmpty() || firstname.isEmpty() || email.isEmpty() || phone.isEmpty() || patientId.isEmpty()) {
                log.error("Invalid input parameters for payment initiation");
                return ErrorConstants.FAILED;
            }

            // Log request details
            log.info("Initiating payment for serviceType: {}, amount: {}, productInfo: {}, firstname: {}, email: {}, patientId: {}",
                    serviceType, amount, productInfo, firstname, email, patientId);

            // Get the correct PayU key and salt for the provided service type
            PayUCategoryConfig.PayUConfigDetails configDetails = payUCategoryConfig.getCategoryConfig(serviceType);

            // Generate a unique transaction ID
            String txnid = UUID.randomUUID().toString();

            // Format amount correctly
            String formattedAmount = String.format("%.2f", amount);  // Ensure correct decimal format

            // Generate the hash for the request
            String hash = HashGenerator.generateHash(configDetails.getKey(), txnid, formattedAmount, productInfo, firstname, email, configDetails.getSalt());

            // Log hash generation
            log.info("Generated hash: {}", hash);

            // Create a TransactionEntity object
            TransactionEntity transaction = new TransactionEntity();
            transaction.setTxnId(txnid);
            transaction.setHash(hash);
            transaction.setFirstName(firstname);
            transaction.setEmail(email);
            transaction.setPhone(phone);
            transaction.setProductInfo(productInfo);
            transaction.setAmount(BigDecimal.valueOf(amount));
            transaction.setTxnDate(new Date()); // Set the transaction date
            transaction.setCreatedDate(new Date()); // Set created date
            transaction.setModifiedDate(new Date()); // Set modified date
            transaction.setCreatedBy("system"); // Set created by
            transaction.setModifiedBy("system"); // Set modified by
            transaction.setStatus(0); // Set initial status
            transaction.setPatientId(patientId); // Set the patient ID

            // Save the transaction to the database
            transactionRepo.save(transaction);
            log.info("Transaction saved with ID: {}", transaction.getId());

            // Create the request body for the PayU API
            Map<String, String> values = new HashMap<>();
            values.put("key", configDetails.getKey());
            values.put("txnid", txnid);
            values.put("amount", formattedAmount);
            values.put("productinfo", productInfo);
            values.put("firstname", firstname);
            values.put("lastname", "");  // Consider removing if not used
            values.put("email", email);
            values.put("phone", phone);
            values.put("surl", surl); // Ensure surl is defined
            values.put("furl", furl); // Ensure furl is defined
            values.put("hash", hash);

            // Build HTML form
            String htmlResponse = buildHtmlForm(values);

            // Log and return the generated HTML response
            log.info("Generated HTML form: {}", htmlResponse);

            return htmlResponse; // Return HTML form to the frontend for auto-submission

        } catch (IllegalArgumentException e) {
            log.error("Invalid argument provided during payment initiation", e);
            return ErrorConstants.FAILED;
        } catch (Exception e) {
            // Log any other exceptions
            log.error("Error occurred during payment initiation", e);
            return ErrorConstants.FAILED;
        }
    }

    // Helper method to create HTML form for auto-submission
    private String buildHtmlForm(Map<String, String> values) {
        return "<html><body>\n"
                + "<div>\n"
                + "  <form id=\"payuform\" action=\"" + "https://test.payu.in/_payment" + "\" name=\"payuform\" method=\"POST\">\n"
                + "    <input type=\"hidden\" name=\"key\" value=\"" + values.get("key").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"txnid\" value=\"" + values.get("txnid").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"productinfo\" value=\"" + values.get("productinfo").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"amount\" value=\"" + values.get("amount").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"email\" value=\"" + values.get("email").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"firstname\" value=\"" + values.get("firstname").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"lastname\" value=\"" + values.get("lastname").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"surl\" value=\"" + values.get("surl").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"furl\" value=\"" + values.get("furl").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"phone\" value=\"" + values.get("phone").trim() + "\"/>\n"
                + "    <input type=\"hidden\" name=\"hash\" value=\"" + values.get("hash").trim() + "\"/>\n"
                + "  </form>\n"
                + "  <script type=\"text/javascript\">\n"
                + "    document.getElementById('payuform').submit();\n"
                + "  </script>\n"
                + "</div>\n"
                + "</body></html>";
    }
}
