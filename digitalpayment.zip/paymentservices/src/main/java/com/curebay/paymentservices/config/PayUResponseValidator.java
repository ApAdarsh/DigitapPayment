package com.curebay.paymentservices.config;

import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

/**
 * Utility class for validating PayU payment response hashes.
 * Ensures that the response received from PayU is authentic and untampered.
 */
@Slf4j
public class PayUResponseValidator {

    /**
     * Generates a response hash based on PayU's expected response format.
     * <p>
     * Hash Format:
     * sha512(SALT|status||||||email|firstname|productinfo|amount|txnid|key)
     *
     * @param responseFields A map containing the response fields from PayU.
     * @param salt           The merchant's salt key provided by PayU.
     * @return The generated SHA-512 hash as a hexadecimal string.
     */
    public static String generateResponseHash(Map<String, String> responseFields, String salt) {
        // Extract required fields from the response
        String key = responseFields.get("key");
        String txnid = responseFields.get("txnid");
        String amount = responseFields.get("amount");
        String productinfo = responseFields.get("productinfo");
        String firstname = responseFields.get("firstname");
        String email = responseFields.get("email");
        String status = responseFields.get("status");

        // Ensure that mandatory fields are present
        if (key == null || txnid == null || amount == null || productinfo == null || firstname == null ||
                email == null || status == null || salt == null) {
            throw new IllegalArgumentException("All required response parameters must be non-null.");
        }

        // Ensure amount is formatted correctly (exactly 2 decimal places)
        String formattedAmount = String.format("%.2f", Double.parseDouble(amount)).trim();

        // Construct the hash input string in the correct format
        String input = salt + "|" + status + "||||||" +
                email.trim() + "|" + firstname.trim() + "|" +
                productinfo.trim() + "|" + formattedAmount.trim() + "|" +
                txnid + "|" + key;

        // Log the exact input string used for hashing (for debugging)
        log.debug("🔍 Response Hash Input String: {}", input);

        return sha512(input);
    }

    /**
     * Computes the SHA-512 hash of the given input string.
     *
     * @param input The input string to hash.
     * @return The SHA-512 hash as a hexadecimal string.
     */
    private static String sha512(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] hashBytes = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString(); // If PayU requires uppercase, use: .toUpperCase()
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-512 algorithm not found.", e);
        }
    }

    /**
     * Validates the PayU response hash by comparing the generated hash with the provided hash.
     *
     * @param responseFields A map containing the response fields from PayU.
     * @param salt           The salt key used for hash generation.
     * @return true if the response hash is valid, false otherwise.
     */
    public static boolean validateResponseHash(Map<String, String> responseFields, String salt) {
        String responseHash = responseFields.get("hash"); // Expected hash from PayU
        String generatedHash = generateResponseHash(responseFields, salt); // Calculated hash

        log.info("🔍 Expected Hash from PayU: {}", responseHash);
        log.info("🔍 Calculated Hash in System: {}", generatedHash);
        // Log both hashes for debugging
        log.debug("🔍 Expected Hash from PayU: {}", responseHash);
        log.debug("🔍 Calculated Hash in System: {}", generatedHash);

        return generatedHash.equalsIgnoreCase(responseHash); // Case-insensitive match
    }
}