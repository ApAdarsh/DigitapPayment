package com.curebay.paymentservices.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TransactionStatusConfig {

    @Value("${transaction.status.pending:2}")
    private int pendingCode;

    @Value("${transaction.status.success:1}")
    private int successCode;

    @Value("${transaction.status.failed:3}")
    private int failedCode;

    @Value("${transaction.status.in_progress:0}")
    private int inProgressCode;

    public int getPendingCode() {
        return pendingCode;
    }

    public int getSuccessCode() {
        return successCode;
    }

    public int getFailedCode() {
        return failedCode;
    }

    public int getInProgressCode() {
        return inProgressCode;
    }
}