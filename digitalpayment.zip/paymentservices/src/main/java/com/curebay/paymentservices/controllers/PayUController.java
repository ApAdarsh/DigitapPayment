package com.curebay.paymentservices.controllers;

import com.curebay.paymentservices.dto.PayURequestDTO;
import com.curebay.paymentservices.services.PayUService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@Validated
@Slf4j
public class PayUController {

    @Autowired
    private PayUService payUService;

    /**
     * Initiates a payment for a given service type.
     *
     * @param requestPayload The request payload containing payment details.
     * @return ResponseEntity containing the HTML form for payment.
     */
    @PostMapping("/payu/initiate")
    public ResponseEntity<String> initiatePayment(@RequestBody PayURequestDTO requestPayload) {
        log.info("Initiating payment for service type: {}", requestPayload.getServiceType());
        log.info("Request Payload: {}", requestPayload); // Log the entire payload

        String htmlForm = payUService.initiatePayment(
                requestPayload.getServiceType(),
                requestPayload.getAmount(),
                requestPayload.getProductInfo(),
                requestPayload.getFirstname(),
                requestPayload.getEmail(),
                requestPayload.getPhone(),
                requestPayload.getPatientId()
        );

        return ResponseEntity.ok(htmlForm); // Send the HTML form as the response
    }
}