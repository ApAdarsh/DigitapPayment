package com.curebay.paymentservices.controllers;

import java.util.Map;
import java.util.Optional;

import com.curebay.paymentservices.config.PayUCategoryConfig;
import com.curebay.paymentservices.config.PayUResponseValidator;
import com.curebay.paymentservices.constants.TransactionStatus;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.curebay.paymentservices.model.TransactionEntity;
import com.curebay.paymentservices.repo.TransactionRepo;

@RestController
@Slf4j
public class PayUResponseController {

    @Value("${merchantSaltNP}")
    private String merchantSalt;

    @Autowired
    private TransactionRepo transactionRepo;

    @PostMapping("/payu/success")
    public ResponseEntity<String> handlePayUSuccess(@RequestParam Map<String, String> allRequestParams) {
        log.info("Received PayU success response: {}", allRequestParams);
        try {
            // Validate required fields
            if (!allRequestParams.containsKey("status") || !allRequestParams.containsKey("txnid") ||
                    !allRequestParams.containsKey("amount") || !allRequestParams.containsKey("hash")) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Missing required parameters");
            }

            // Extract response fields
            String status = allRequestParams.get("status");
            String txnid = allRequestParams.get("txnid");
            String amount = allRequestParams.get("amount");
            String hash = allRequestParams.get("hash");
//            PayUCategoryConfig.PayUConfigDetails configDetails = payUCategoryConfig.getCategoryConfig(serviceType);

            // Validate the response hash
            boolean isValidHash = PayUResponseValidator.validateResponseHash(allRequestParams, merchantSalt);

            log.info("Hash validation result for txnId {}: {}", txnid, isValidHash);
            if (isValidHash && "success".equalsIgnoreCase(status)) {
                // Payment was successful and hash is valid
                log.info("Payment successful for transaction ID: {}", txnid);

                // Update the transaction status in the database
                Optional<TransactionEntity> transactionOpt = transactionRepo.findByTxnId(txnid);
                if (transactionOpt.isPresent()) {
                    TransactionEntity transaction = transactionOpt.get();
                    transaction.setStatus(TransactionStatus.SUCCESS.getCode()); // Set status to SUCCESS
                    transactionRepo.save(transaction);
                } else {
                    log.error("Transaction not found for txnId: {}", txnid);
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Transaction not found");
                }

                // Return a success HTML response
                return ResponseEntity.ok(buildSuccessHtml(txnid, amount));
            } else {
                // Payment failed or hash validation failed
                log.error("Payment failed or hash invalid for transaction ID: {}", txnid);
                Optional<TransactionEntity> transactionOpt = transactionRepo.findByTxnId(txnid);
                if (transactionOpt.isPresent()) {
                    TransactionEntity transaction = transactionOpt.get();
                    transaction.setStatus(TransactionStatus.FAILED.getCode()); // Set status to FAILED
                    transactionRepo.save(transaction);
                }
                return ResponseEntity.ok(buildFailureHtml(txnid));
            }

        } catch (Exception e) {
            log.error("Error while handling PayU response", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal error");
        }
    }


    @PostMapping("/payu/failure")
    public ResponseEntity<String> handlePayUFailure(@RequestParam Map<String, String> allRequestParams) {
        log.info("Received PayU failure response: {}", allRequestParams);
        // You can log the failure response and handle it as needed
        return ResponseEntity.ok(buildFailureHtml(allRequestParams.get("txnid")));
    }
    private String buildSuccessHtml(String txnid, String amount) {
        return "<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Payment Successful</title>\n" +
                "    <style>\n" +
                "        body {\n" +
                "            font-family: 'Arial', sans-serif;\n" +
                "            text-align: center;\n" +
                "            background: linear-gradient(135deg, #1D976C, #93F9B9);\n" +
                "            color: white;\n" +
                "            padding: 50px;\n" +
                "        }\n" +
                "        .container {\n" +
                "            max-width: 450px;\n" +
                "            background: white;\n" +
                "            padding: 30px;\n" +
                "            border-radius: 12px;\n" +
                "            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);\n" +
                "            margin: auto;\n" +
                "            color: black;\n" +
                "            animation: fadeIn 1s;\n" +
                "        }\n" +
                "        @keyframes fadeIn {\n" +
                "            from { opacity: 0; transform: translateY(-20px); }\n" +
                "            to { opacity: 1; transform: translateY(0); }\n" +
                "        }\n" +
                "        .checkmark {\n" +
                "            font-size: 60px;\n" +
                "            color: #2ECC71;\n" +
                "            margin-bottom: 15px;\n" +
                "        }\n" +
                "        .transaction-info {\n" +
                "            font-size: 18px;\n" +
                "            color: #333;\n" +
                "        }\n" +
                "        .btn {\n" +
                "            display: inline-block;\n" +
                "            margin-top: 20px;\n" +
                "            padding: 12px 24px;\n" +
                "            background-color: #28a745;\n" +
                "            color: white;\n" +
                "            text-decoration: none;\n" +
                "            font-weight: bold;\n" +
                "            border-radius: 6px;\n" +
                "            transition: 0.3s;\n" +
                "        }\n" +
                "        .btn:hover {\n" +
                "            background-color: #218838;\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <div class=\"checkmark\">✔</div>\n" +
                "        <h1>Payment Successful</h1>\n" +
                "        <p class=\"transaction-info\">Your payment of <strong>₹" + amount + "</strong> was successful!</p>\n" +
                "        <p class=\"transaction-info\">Transaction ID: <strong>" + txnid + "</strong></p>\n" +
                "        <a href=\"/\" class=\"btn\">Return to Home</a>\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>\n";
    }

    private String buildFailureHtml(String txnid) {
        return "<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>Payment Failed</title>\n" +
                "    <style>\n" +
                "        body {\n" +
                "            font-family: 'Arial', sans-serif;\n" +
                "            text-align: center;\n" +
                "            background: linear-gradient(135deg, #FF512F, #DD2476);\n" +
                "            color: white;\n" +
                "            padding: 50px;\n" +
                "        }\n" +
                "        .container {\n" +
                "            max-width: 450px;\n" +
                "            background: white;\n" +
                "            padding: 30px;\n" +
                "            border-radius: 12px;\n" +
                "            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);\n" +
                "            margin: auto;\n" +
                "            color: black;\n" +
                "            animation: fadeIn 1s;\n" +
                "        }\n" +
                "        @keyframes fadeIn {\n" +
                "            from { opacity: 0; transform: translateY(-20px); }\n" +
                "            to { opacity: 1; transform: translateY(0); }\n" +
                "        }\n" +
                "        .crossmark {\n" +
                "            font-size: 60px;\n" +
                "            color: #E74C3C;\n" +
                "            margin-bottom: 15px;\n" +
                "        }\n" +
                "        .transaction-info {\n" +
                "            font-size: 18px;\n" +
                "            color: #333;\n" +
                "        }\n" +
                "        .btn {\n" +
                "            display: inline-block;\n" +
                "            margin-top: 20px;\n" +
                "            padding: 12px 24px;\n" +
                "            background-color: #d9534f;\n" +
                "            color: white;\n" +
                "            text-decoration: none;\n" +
                "            font-weight: bold;\n" +
                "            border-radius: 6px;\n" +
                "            transition: 0.3s;\n" +
                "        }\n" +
                "        .btn:hover {\n" +
                "            background-color: #c9302c;\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <div class=\"crossmark\">✖</div>\n" +
                "        <h1>Payment Failed</h1>\n" +
                "        <p class=\"transaction-info\">Unfortunately, your payment was unsuccessful.</p>\n" +
                "        <p class=\"transaction-info\">Transaction ID: <strong>" + txnid + "</strong></p>\n" +
                "        <p>Please try again or contact support.</p>\n" +
                "        <a href=\"/retry-payment\" class=\"btn\">Retry Payment</a>\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>\n";
    }

}

