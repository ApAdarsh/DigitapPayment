package com.curebay.paymentservices.config;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Configuration
public class PayUCategoryConfig {

    @Value("${merchantKey}")
    private String merchantKey;

    @Value("${merchantSalt}")
    private String merchantSalt;

    @Value("${merchantKeyNP}")
    private String merchantKeyNP;

    @Value("${merchantSaltNP}")
    private String merchantSaltNP;

    private final Map<String, PayUConfigDetails> categoryMap = new HashMap<>();
    private final Set<String> category1 = new HashSet<>();
    private final Set<String> category2 = new HashSet<>();

    @PostConstruct
    public void init() {
        // Initialize service types for each category
        category1.add("membership");
        category1.add("appointment");
        category1.add("laborder");

        category2.add("pharmacyorder");
        category2.add("eclinictest");
        category2.add("packages");

        // Populate the category map
        categoryMap.put("category1", new PayUConfigDetails(merchantKey, merchantSalt));
        categoryMap.put("category2", new PayUConfigDetails(merchantKeyNP, merchantSaltNP));
    }

    // This method fetches the configuration based on the service type
    public PayUConfigDetails getCategoryConfig(String serviceType) {
        if (category1.contains(serviceType)) {
            return categoryMap.get("category1");
        } else if (category2.contains(serviceType)) {
            return categoryMap.get("category2");
        } else {
            throw new IllegalArgumentException("Unknown service type: " + serviceType);
        }
    }

    // Inner class to store key and salt for each category
    public static class PayUConfigDetails {
        private final String key;
        private final String salt;

        public PayUConfigDetails(String key, String salt) {
            this.key = key;
            this.salt = salt;
        }

        public String getKey() {
            return key;
        }

        public String getSalt() {
            return salt;
        }
    }
}