package com.curebay.paymentservices.constants;

public enum TransactionStatus {
    PENDING(2),
    SUCCESS(1),
    FAILED(3),
    IN_PROGRESS(0);

    private final int code;

    TransactionStatus(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}