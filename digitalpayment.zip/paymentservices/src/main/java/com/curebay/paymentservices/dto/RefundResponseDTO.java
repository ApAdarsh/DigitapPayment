package com.curebay.paymentservices.dto;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class RefundResponseDTO {
    private String status;
    private double refundedAmount;
    private String message;
}
