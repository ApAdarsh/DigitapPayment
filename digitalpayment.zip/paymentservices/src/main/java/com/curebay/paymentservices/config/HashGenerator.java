package com.curebay.paymentservices.config;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashGenerator {

    /**
     * Generates a hash for the payment request based on the provided parameters.
     *
     * @param key         The merchant key.
     * @param txnid       The transaction ID.
     * @param amount      The transaction amount.
     * @param productInfo The product information.
     * @param firstname   The first name of the customer.
     * @param email       The email of the customer.
     * @param salt        The merchant salt.
     * @return The generated hash as a hexadecimal string.
     */
    public static String generateHash(String key, String txnid, String amount, String productInfo, String firstname, String email, String salt) {
        // Input validation
        if (key == null || txnid == null || amount == null || productInfo == null || firstname == null || email == null || salt == null) {
            throw new IllegalArgumentException("All parameters must be non-null");
        }

        // Construct the input string according to the specified formula
        String input = key + "|" + txnid + "|" + amount + "|" + productInfo + "|" + firstname + "|" + email + "|||||||||||" + salt;
        return sha512(input);
    }

    /**
     * Computes the SHA-512 hash of the given input string.
     *
     * @param input The input string to hash.
     * @return The SHA-512 hash as a hexadecimal string.
     */
    private static String sha512(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] hashBytes = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-512 algorithm not found", e);
        }
    }

}