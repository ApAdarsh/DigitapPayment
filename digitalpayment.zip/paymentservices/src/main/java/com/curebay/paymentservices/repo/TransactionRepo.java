package com.curebay.paymentservices.repo;


import com.curebay.paymentservices.model.TransactionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TransactionRepo extends JpaRepository<TransactionEntity, Long> {
//        TransactionEntity findByTransactionId(String transactionId);
Optional<TransactionEntity> findByTxnId(String txnId);
}
