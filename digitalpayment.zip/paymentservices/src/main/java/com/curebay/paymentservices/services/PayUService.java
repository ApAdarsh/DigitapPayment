package com.curebay.paymentservices.services;

public interface PayUService {

    String initiatePayment(String serviceType, double amount, String productInfo, String firstname, String email, String phone,String patientId);

}
